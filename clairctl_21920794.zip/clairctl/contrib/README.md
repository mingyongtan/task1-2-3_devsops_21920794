CONTRIBUTION
-----------------

# Running a development environnement

```bash
# Running Authentication server, Registry, Clair
docker-compose up -d

# Run Any command ex:
go run main.go help
# Or
go run main.go pull registry:5000/wemanity-belgium/ubuntu-git
```
